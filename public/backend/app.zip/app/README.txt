Hypermedia Applications 2019-2020

mettere lo swagger.yaml recente in spec.yaml

PRACTICAL INFO X2
ABOUT US
